﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentCares.GetMaxItemno
{
    internal class GetData
    {

        public static void getMaxItem()
        {
            try
            {
                string sql = "Select MAX(userID)from Profiles1";
                Connection.Connections.DB();
                GlobalDeclaration.command = new OleDbCommand(sql,
               Connection.Connections.conn);
                GlobalDeclaration.reader = GlobalDeclaration.command.ExecuteReader();
                if (GlobalDeclaration.reader.Read())
                {
                    sql = GlobalDeclaration.reader[0].ToString();
                    if (sql == "")
                    {
                        GlobalDeclaration.itemcode = 1;
                    }
                    else
                    {
                        GlobalDeclaration.itemcode =
                       Convert.ToInt32(GlobalDeclaration.reader[0].ToString()) + 1;

                    }
                    GlobalDeclaration.reader.Close();
                }
                Connection.Connections.conn.Close();
            }



 catch (Exception ex)
 {
                Connection.Connections.conn.Close();
                MessageBox.Show("Error ----> GET MAX ID" + ex.Message);
            }
        }
        public static void getMaxORNO()
        {
            try
            {
                string sql = "Select MAX(orno) from sales_master";
                Connection.Connections.DB();
                GlobalDeclaration.command = new OleDbCommand(sql,
               Connection.Connections.conn);
                GlobalDeclaration.reader = GlobalDeclaration.command.ExecuteReader();
                if (GlobalDeclaration.reader.Read())
                {
                    sql = GlobalDeclaration.reader[0].ToString();
                    if (sql == "")
                    {
                        GlobalDeclaration.ORNO = 10001;
                    }
                    else
                    {
                        // int a = Convert.ToInt32(GlobalDeclaration.reader[0].ToString());
                        GlobalDeclaration.ORNO =
                       Convert.ToInt32(GlobalDeclaration.reader[0].ToString()) + 1;
                    }
                    GlobalDeclaration.reader.Close();
                }
                Connection.Connections.conn.Close();
            }
            catch (Exception ex)
            {
                Connection.Connections.conn.Close();
                MessageBox.Show("Error ----> GET MAX ORNo" + ex.Message);
            }
        } 

    }
}
