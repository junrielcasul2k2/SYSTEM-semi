﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentCares.DbHelper
{
    internal class Helper
    {
        //used for database transaction
        public static string gen = "";
        public static OleDbConnection conn;
        public static OleDbCommand command;
        public static OleDbDataReader reader;
        public static void fill(string q, DataGridView dgv)
        {
            
        try
            {
                Connection.Connections.DB();
                DataTable dt = new DataTable();
                OleDbDataAdapter data = null;
                OleDbCommand command = new OleDbCommand(q,
               Connection.Connections.conn);
                data = new OleDbDataAdapter(command);
                data.Fill(dt);
                dgv.DataSource = dt;
                Connection.Connections.conn.Close();
            }
            catch (Exception ex)
            {
                Connection.Connections.conn.Close();
                MessageBox.Show(ex.Message, "Error FillDataGridView",MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }
        public static void ModifyRecord(string updates)
        {
            try
            {
                Connection.Connections.DB();
                OleDbCommand command = new OleDbCommand(updates,
               Connection.Connections.conn);
                command.ExecuteNonQuery();
                Connection.Connections.conn.Close();
            }
            catch (Exception ex)
            {
                Connection.Connections.conn.Close();
                MessageBox.Show("Error ---->" + updates + ex.Message);
            }
        }

    }
}
