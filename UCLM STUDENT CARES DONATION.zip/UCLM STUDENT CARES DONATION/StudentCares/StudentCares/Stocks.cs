﻿using StudentCares.DbHelper;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace StudentCares
{
    
    public partial class Stocks : Form
    {
        private OleDbConnection conn;
        private OleDbCommand cmd;
        private OleDbDataAdapter adapter;
        private DataTable dt;
        private string sql;
        public Stocks()
        {
            InitializeComponent();
        }

        void displayTables()
        {
            conn = new OleDbConnection("Provider=Microsoft.ACE.OleDb.16.0; Data Source=" + Application.StartupPath + "\\Account.accdb");
            dt = new DataTable();
            adapter = new OleDbDataAdapter("SELECT *FROM Profiles1", conn);
            conn.Open();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
            conn.Close();
        }
        private void Stocks_Load(object sender, EventArgs e)
        {
            lblsend.Text = "Welcome " + Login.sendtext;
          string  sql = "SELECT * from Profiles1";
            DbHelper.Helper.fill(sql, dataGridView1);
            GetMaxItemno.GetData.getMaxItem();
            txtID.Text = GetMaxItemno.GlobalDeclaration.itemcode.ToString();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void addbtn_Click(object sender, EventArgs e)
        {
            try
            {

                //sql = "INSERT INTO 
                //  Profiles1(UserID, FirstName, LastName, Course, Unit, Expirydate, Datemodified, Stockonhand, Category) values("+txtItemNo.Text+", '"+txtdescription.Text+"', '" +txtsprice.Text + "'," + txtreorderpoint.Text + ",'" + txtunit.Text + "','" + dpexpirydate.Text + "','" + DateTime.Now.ToShortDateString() + "'," + txtstockonhand.Text + ",'" + cbocategory.Text + "')";" +


                sql = "INSERT INTO Profiles1(userID, FirstName, LastName, DonatedFunds, Course, DateDonated, DateModified, DonatedThings, userRole )" +
                                "values(" + txtID.Text + "," +
                                " '" + txtfname.Text + "'," +
                                 " '" + txtlname.Text + "'," +
                                 " " + txtFunds.Text + "," +
                                 " '" + txtCourse.Text + "'," +
                                 " '" + dateTimePicker1.Value.Date + "'," +
                                 " '" + dateM.Value.Date + "'," +
                                 " '" + DateTime.Now.ToShortDateString() + "'," +
                                 " '" + txtThings.Text + "'," +
                                 " '" + cmbRole.Text +"')";
                DbHelper.Helper.ModifyRecord(sql);
                MessageBox.Show("Data has been added...", "Save new stock",
               MessageBoxButtons.OK, MessageBoxIcon.Information);
                Stocks_Load(sender, e);
                clearfields();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
 
        private void clearfields()
        {
            // txtItemNo.Clear();
            txtID.Clear();
            txtfname.Clear();
            txtlname.Clear();
            txtCourse.Clear();
            dateTimePicker1.Text = System.DateTime.Now.ToShortDateString();
             txtFunds.Text = "";
            txtThings.Clear();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker2_ValueChanged_1(object sender, EventArgs e)
        {

        }
    }
}
