﻿using StudentCares.DbHelper;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace StudentCares
{
    public partial class Login : Form
    {
        public static string sendtext = "";
        
        public Login()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            panel5.Visible = false;
            panel7.Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //retrieving username and password from the database
            try
            {
                Connection.Connections.DB();
                DbHelper.Helper.gen = "Select * from Users where [username] = '" + textBox1.Text + "' and [password] = '" + textBox2.Text + "'";
                DbHelper.Helper.command = new OleDbCommand(DbHelper.Helper.gen, Connection.Connections.conn);
                DbHelper.Helper.reader = DbHelper.Helper.command.ExecuteReader();


                

                if (DbHelper.Helper.reader.HasRows)
                {
                    DbHelper.Helper.reader.Read();
                    //database  
                    textBox1.Text = (DbHelper.Helper.reader["username"].ToString());
                    textBox2.Text = (DbHelper.Helper.reader["password"].ToString());
                    // open a next form  
                    //  Stocks s = new Stocks ();
                    //  s.Show();
                    //   this.Visible =false;//cosing the form
                    //   sale.Show();l

                    timer1.Enabled = true;
                    timer1.Start();
                    timer1.Interval = 1;
                    progressBar1.Maximum = 200;
                    timer1.Tick += new EventHandler(timer1_Tick);


                }
                else  
                {
                    panel5.Visible = true;
                    panel7.Visible=true;
                
                }

                Connection.Connections.conn.Close();
            }

            catch (Exception ex)
            {
                Connection.Connections.conn.Close();
                MessageBox.Show(ex.Message);

            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        
 
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (progressBar1.Value != 200)
            {
                progressBar1.Value++;
            }
            else
            {
                timer1.Stop();
                this.Hide();

                progressBar1.Value = 0;
                sendtext = textBox1.Text;
                Stocks s = new Stocks();
                s.Show();
            
        }
    }

        
        private void textBox1_TextChanged_2(object sender, EventArgs e)
        {
             try
            {
                   textBox1.ForeColor = Color.CornflowerBlue;
 
            }
            catch
            {
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
             
            try
            {
 
                textBox2.ForeColor = Color.CornflowerBlue;
                textBox2.UseSystemPasswordChar = false;

            }
            catch
            {
            }
        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "Username")
            {
                textBox1.Clear();

            }
            
         }

        private void textBox2_Click(object sender, EventArgs e)
        {
            if (textBox2.Text == "Password")
            {
                textBox2.UseSystemPasswordChar = false;

                textBox2.Clear();

            }
             
        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            if (textBox1.Text == "")  
            {
                textBox1.Text = "Username";
                textBox1.ForeColor = Color.Silver;
            }
        }

        private void textBox2_Leave(object sender, EventArgs e)
        {
            if (textBox2.Text == "")
            {
 
                textBox2.Text = "Password";
                textBox2.ForeColor = Color.Silver;
            }
        }

        private void button1_MouseClick(object sender, MouseEventArgs e)
        {
           
        }

        private void button1_MouseLeave(object sender, EventArgs e)
        {
            button1.ForeColor = Color.White;
            button1.BackColor = Color.CornflowerBlue;
        }

        private void button1_MouseEnter(object sender, EventArgs e)
        {
            button1.ForeColor = Color.CornflowerBlue;
            button1.BackColor = Color.WhiteSmoke;

        }
        private void progressBar1_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }



        private void panel1_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
             if (ShowPass.Checked)
            {
                textBox2.UseSystemPasswordChar = false;
            }
            else 
            {
                textBox2.UseSystemPasswordChar= true;
            }
        }
    }
}
